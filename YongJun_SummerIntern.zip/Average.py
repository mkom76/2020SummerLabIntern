import pandas as pd 
import time
#import cufflinks as cf
#import plotly.plotly as py
#cf.go_offline(connected=True)
pd.options.plotting.backend = "plotly"

# 만약 알고 싶은 데이터를 추가하고 싶을 경우 밑의 4 Line만 수정
BrainWave = [' Delta', ' Theta', ' Alpha1', ' Alpha2', ' Beta1', ' Beta2', ' Gamma1', ' Gamma2']
WaveNum = 8
BrainWaveList = [0,0,0,0,0,0,0,0] # 평균값 계산을 위한 리스트
real_df = pd.DataFrame({' Delta':[0], ' Theta':[0], ' Alpha1':[0], ' Alpha2':[0], ' Beta1':[0], ' Beta2':[0], ' Gamma1':[0], ' Gamma2':[0]})


Length = int(input("Data Length: ")) # 몇 초 단위로 데이터를 평균낼지 정함
Count = 0 # 데이터를 순차적으로 수집하다가 length만큼 수집하게되면 연산 후 그래프출력
Line = 0 # 접근하고자하는 row 데이터
##real_df = pd.DataFrame(BrainWaveList, index = BrainWave, rows = [Time]) 
print(real_df)

while(1):# 그래프 그리는 시간 고려하여 각 연산간격 0.5로 설정. 만약 데이터값이 나오지 않았으면 0.5초 더 기다린 후 다시 취함
    Flag = True
    while(Flag):
        try:
            data = pd.read_csv("./Log.csv")# Log.csv 를 읽어서 data Frame 형태로 저장 
            df = data.iloc[[Line]]
            Flag = False
        except Exception:
            time.sleep(0.5)
            pass
        #df = data.tail(1) # 마지막 줄을 Data Frame 형태로 저장 (이 부분을 1초마다 바꿔서 저장하면 정기적으로 받아올 수 있어요)
    print(df)


    #  그다음에 df를 sql로 db 에 넣으면 돼요 
    #  DB 서버는 없으시면 드릴 순 있는데, 필요하면 한번 설치도 해보세요(언젠가 한번 하실 일이니깐)

    if(Count < Length):
        for i in range(WaveNum):
            BrainWaveList[i] += df[BrainWave[i]].values[0]
    else: # 사용자가 지정한 범위만큼 평균값 내기
        for i in range(WaveNum):
            BrainWaveList[i] /= Length
        # real_df = pd.DataFrame(BrainWaveList, index = BrainWave, columns = ['AverageValue']) # 모든 뇌파의 평균값이 dataframe형태로 저장됨
        ##real_df[Time] = BrainWaveList
        a = pd.DataFrame(data=[BrainWaveList], columns=BrainWave)
        real_df = real_df.append(a)
        real_df = real_df.reset_index(drop=True)
        print(real_df)
        real_df.to_csv(r'./Average.csv', index = False, header = True) # 떨어지는 파일 경로조정 가능
        fig = real_df.plot.line()
        fig.show()
        # 데이터베이스에 값 보내기 추가
        for i in range(WaveNum):# 새로 받은 데이터값으로 갱신
            BrainWaveList[i] = df[BrainWave[i]].values[0]
        Count = 0

    #print(Value)    # df.(column 명).values -> 각 column에 해당하는 value 값 출력..
    Count += 1
    Line += 1
    time.sleep(0.3)